package ca.sfu.cmpt362.group4.streamline.data_models

data class User(
    val uid: String = "",
    val name: String = "",
    val email: String = ""
)